/*
    Student Name         : Jian Ira Olvido Farne
    UOWID                : 7433645
    Tutorial Class       : T01
    Asssignment          : 03
*/

#ifndef SUB_MENU_H
#define SUB_MENU_H

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <fstream>
#include <limits>

using namespace std;

//To filter options
void filterOption();

//To sort options
void sortingOption();

//To sort order
void sortOrder();
#endif