/*
    To compile (In Windows): 
		g++ -std=c++17 Line2D.cpp Line3D.cpp Point2D.cpp Point3D.cpp Utility.cpp ProcessStorePoints.cpp ProcessStoreLines.cpp SubMenu.cpp Sorting.cpp FileOutput.cpp 7433645_A3.cpp -o csci251_a3_windows.exe

	To compile (In Ubuntu): 
		g++ -std=c++17 Line2D.cpp Line3D.cpp Point2D.cpp Point3D.cpp Utility.cpp ProcessStorePoints.cpp ProcessStoreLines.cpp SubMenu.cpp Sorting.cpp FileOutput.cpp 7433645_A3.cpp -o csci251_a3_ubuntu.exe
*/