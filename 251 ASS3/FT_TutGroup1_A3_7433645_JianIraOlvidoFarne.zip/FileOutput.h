/*
    Student Name         : Jian Ira Olvido Farne
    UOWID                : 7433645
    Tutorial Class       : T01
    Asssignment          : 03
*/

#ifndef FILE_OUTPUT_H
#define FILE_OUTPUT_H

#include <iostream>
#include <vector>
#include <string>
#include <iomanip>
#include <algorithm>
#include <fstream>
#include <limits>

#include "Sorting.h"

using namespace std;
//To write .txt file
void writingToFile();

#endif