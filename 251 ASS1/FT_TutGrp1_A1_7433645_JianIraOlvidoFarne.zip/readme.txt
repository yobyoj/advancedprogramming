Name		: Farne, Jian Ira Olvido
UOWID		: 7433645
Assignment	: 01
File		: ReadMe.txt

Compiling the code:

/*
	To compile (In Windows): 
		g++ 7433645_A1.cpp -std=c++11 -o 7433645_a1.exe
*/

Running the code:

./7433645_a1

