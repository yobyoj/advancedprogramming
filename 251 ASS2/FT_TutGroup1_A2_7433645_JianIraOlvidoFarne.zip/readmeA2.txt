/*
    To compile (In Windows): 
        g++ -std=c++17 ShapeTwoD.cpp Square.cpp Rectangle.cpp Cross.cpp Circle.cpp OtherFunctions.cpp 7433645_A2.cpp -o csci251_a2_windows.exe

    To Run:
    ./csci251_a2_windows.exe


    To compile (In Ubuntu): 
        g++ -std=c++17 ShapeTwoD.cpp Square.cpp Rectangle.cpp Cross.cpp Circle.cpp OtherFunctions.cpp 7433645_A2.cpp -o csci251_a2_ubuntu.exe
    
    To Run:
    ./csci251_a2_ubuntu.exe

*/